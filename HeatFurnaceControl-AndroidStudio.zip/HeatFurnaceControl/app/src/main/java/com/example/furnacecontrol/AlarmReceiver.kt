package com.example.furnacecontrol

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

object AlarmHelper {
    private const val CHANNEL = "furnace_finished"

    fun schedule(context: Context, timer: FurnaceTimer) {
        if (!timer.running) return
        val intent = Intent(context, AlarmReceiver::class.java).putExtra("furnace_id", timer.id)
        val pi = PendingIntent.getBroadcast(context, timer.id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timer.endAt, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timer.endAt, pi)
        }
    }

    fun cancel(context: Context, id: Int) {
        val pi = PendingIntent.getBroadcast(context, id,
            Intent(context, AlarmReceiver::class.java).putExtra("furnace_id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
    }

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(CHANNEL, "Окончание обработки",
                NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null) // Звук воспроизводит отдельный сервис до подтверждения
                enableVibration(true)
                setShowBadge(true)
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun startRinging(context: Context) {
        val intent = Intent(context, FurnaceAlarmService::class.java)
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
        else context.startService(intent)
    }

    fun stopRinging(context: Context) {
        context.stopService(Intent(context, FurnaceAlarmService::class.java))
    }

    fun refreshRinging(context: Context) {
        val anyWaiting = TimerStore.load(context).any { it.completed }
        if (anyWaiting) startRinging(context) else stopRinging(context)
    }

    fun notification(context: Context) = NotificationCompat.Builder(context, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle("Требуется выгрузка")
        .setContentText("Есть печь, ожидающая подтверждения оператора")
        .setPriority(NotificationCompat.PRIORITY_MAX)
        .setCategory(NotificationCompat.CATEGORY_ALARM)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .build()
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("furnace_id", -1)
        val timer = TimerStore.load(context).firstOrNull { it.id == id } ?: return
        if (!timer.running || timer.endAt > System.currentTimeMillis()) return
        val finished = timer.copy(completed = true)
        TimerStore.update(context, id) { finished }
        AlarmHelper.ensureChannel(context)
        AlarmHelper.startRinging(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        TimerStore.load(context).forEach { timer ->
            if (timer.running) {
                if (timer.endAt <= System.currentTimeMillis()) {
                    TimerStore.update(context, timer.id) { it.copy(completed = true) }
                } else AlarmHelper.schedule(context, timer)
            }
        }
        AlarmHelper.refreshRinging(context)
    }
}

class FurnaceAlarmService : Service() {
    private var ringtone: Ringtone? = null

    override fun onCreate() {
        super.onCreate()
        AlarmHelper.ensureChannel(this)
        startForeground(9000, AlarmHelper.notification(this))
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
            if (Build.VERSION.SDK_INT >= 28) isLooping = true
            play()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Сервис продолжает работать, пока хотя бы одна печь ожидает подтверждения.
        if (TimerStore.load(this).none { it.completed }) stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        ringtone?.stop()
        ringtone = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
