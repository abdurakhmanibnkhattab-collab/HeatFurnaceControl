package com.example.furnacecontrol

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { FurnaceScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FurnaceScreen() {
    val context = LocalContext.current
    var timers by remember { mutableStateOf(TimerStore.load(context)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var selected by remember { mutableStateOf<FurnaceTimer?>(null) }
    var hours by remember { mutableStateOf("1") }
    var minutes by remember { mutableStateOf("0") }
    var renameTarget by remember { mutableStateOf<FurnaceTimer?>(null) }
    var newName by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
            timers = TimerStore.load(context)
        }
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Контроль термопечей") }) }) { padding ->
            Column(Modifier.padding(padding).padding(16.dp)) {
                Text("8 печей · таймеры работают независимо", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(timers, key = { it.id }) { timer ->
                        val remaining = (timer.endAt - now).coerceAtLeast(0L) / 1000L
                        val time = String.format(Locale.getDefault(), "%02d:%02d:%02d",
                            remaining / 3600, (remaining % 3600) / 60, remaining % 60)
                        Card {
                            Column(Modifier.padding(12.dp)) {
                                Text(timer.name, style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                when {
                                    timer.running -> {
                                        Text(time, style = MaterialTheme.typography.headlineSmall,
                                            color = MaterialTheme.colorScheme.primary)
                                        Text("В работе")
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedButton(onClick = {
                                            AlarmHelper.cancel(context, timer.id)
                                            TimerStore.update(context, timer.id) { it.copy(endAt = 0L, completed = false) }
                                            AlarmHelper.refreshRinging(context)
                                            timers = TimerStore.load(context)
                                        }) { Text("Остановить") }
                                    }
                                    timer.completed -> {
                                        Text("ВРЕМЯ ВЫШЛО", color = MaterialTheme.colorScheme.error)
                                        Button(onClick = {
                                            TimerStore.update(context, timer.id) { it.copy(endAt = 0L, completed = false) }
                                            AlarmHelper.refreshRinging(context)
                                            timers = TimerStore.load(context)
                                        }) { Text("Выгружено") }
                                    }
                                    else -> {
                                        Text("Свободна")
                                        Button(onClick = { selected = timer }) { Text("Загрузить") }
                                    }
                                }
                                TextButton(onClick = { renameTarget = timer; newName = timer.name }) {
                                    Text("Изменить название")
                                }
                            }
                        }
                    }
                }
            }
        }

        selected?.let { timer ->
            AlertDialog(
                onDismissRequest = { selected = null },
                title = { Text("Время обработки · ${timer.name}") },
                text = {
                    Column {
                        OutlinedTextField(hours, { hours = it.filter(Char::isDigit).take(3) },
                            label = { Text("Часы") })
                        OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit).take(2) },
                            label = { Text("Минуты") })
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val total = (hours.toLongOrNull() ?: 0L) * 60 +
                            (minutes.toLongOrNull() ?: 0L)
                        if (total > 0 && (minutes.toIntOrNull() ?: 0) < 60) {
                            val started = timer.copy(endAt = System.currentTimeMillis() + total * 60_000L,
                                completed = false)
                            TimerStore.update(context, timer.id) { started }
                            AlarmHelper.schedule(context, started)
                            timers = TimerStore.load(context)
                            selected = null
                        }
                    }) { Text("Запустить") }
                },
                dismissButton = { TextButton(onClick = { selected = null }) { Text("Отмена") } }
            )
        }

        renameTarget?.let { timer ->
            AlertDialog(
                onDismissRequest = { renameTarget = null },
                title = { Text("Название печи") },
                text = { OutlinedTextField(newName, { newName = it }, label = { Text("Название") }) },
                confirmButton = {
                    TextButton(onClick = {
                        if (newName.isNotBlank()) {
                            TimerStore.update(context, timer.id) { it.copy(name = newName.trim()) }
                            timers = TimerStore.load(context)
                        }
                        renameTarget = null
                    }) { Text("Сохранить") }
                },
                dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Отмена") } }
            )
        }
    }
}
